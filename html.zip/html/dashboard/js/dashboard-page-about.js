function initAboutEditors() {
  if (!window.tinymce) {
    console.error("TinyMCE не найден");
    return Promise.resolve();
  }

  return tinymce.init({
    selector: "#story_content, #mission_content",
    license_key: "gpl",
    menubar: false,
    branding: false,
    height: 320,
    plugins: "lists link table code wordcount autoresize",
    toolbar:
      "undo redo | blocks | bold italic underline | bullist numlist | link blockquote | alignleft aligncenter alignright | removeformat code",
    content_style: `
      body {
        font-family: Inter, Arial, sans-serif;
        font-size: 16px;
        line-height: 1.7;
        color: #2f352f;
      }
      p { margin: 0 0 1em; }
    `,
  });
}

function bindBlockToggles() {
  document.addEventListener("click", (event) => {
    const button = event.target.closest("[data-toggle-block]");
    if (!button) return;

    const blockId = button.dataset.toggleBlock;
    const block = document.getElementById(blockId);
    if (!block) return;

    block.hidden = !block.hidden;
    button.textContent = block.hidden ? "Редактировать" : "Скрыть";
  });
}

function fillAboutPreview(page) {
  const titleNode = document.getElementById("aboutPreviewTitle");
  const leadNode = document.getElementById("aboutPreviewLead");
  const storyTitleNode = document.getElementById("aboutPreviewStoryTitle");
  const storyContentNode = document.getElementById("aboutPreviewStoryContent");
  const missionTitleNode = document.getElementById("aboutPreviewMissionTitle");
  const missionContentNode = document.getElementById("aboutPreviewMissionContent");

  if (titleNode) titleNode.textContent = page.title || "—";
  if (leadNode) leadNode.textContent = page.lead || "—";
  if (storyTitleNode) storyTitleNode.textContent = page.story_title || "—";

  if (storyContentNode) {
    storyContentNode.innerHTML = page.story_content || "—";
    if (!page.story_content) storyContentNode.textContent = "—";
  }

  if (missionTitleNode) missionTitleNode.textContent = page.mission_title || "—";

  if (missionContentNode) {
    missionContentNode.innerHTML = page.mission_content || "—";
    if (!page.mission_content) missionContentNode.textContent = "—";
  }
}

function fillAboutImagePreview(imagePath) {
  const preview = document.getElementById("aboutImagePreview");
  const previewEmpty = document.getElementById("aboutImagePreviewEmpty");

  if (!preview || !previewEmpty) return;

  if (imagePath) {
    preview.src = dashboardImageUrl(imagePath);
    preview.hidden = false;
    previewEmpty.hidden = true;
    return;
  }

  preview.removeAttribute("src");
  preview.hidden = true;
  previewEmpty.hidden = false;
}

function fillAboutPageForm(form, page) {
  form.title.value = page.title || "";
  form.lead.value = page.lead || "";
  form.story_title.value = page.story_title || "";
  form.mission_title.value = page.mission_title || "";

  const storyEditor = window.tinymce ? tinymce.get("story_content") : null;
  const missionEditor = window.tinymce ? tinymce.get("mission_content") : null;

  if (storyEditor && storyEditor.initialized) {
    storyEditor.setContent(page.story_content || "");
  } else if (form.story_content) {
    form.story_content.value = page.story_content || "";
  }

  if (missionEditor && missionEditor.initialized) {
    missionEditor.setContent(page.mission_content || "");
  } else if (form.mission_content) {
    form.mission_content.value = page.mission_content || "";
  }

  fillAboutImagePreview(page.image || "");
  fillAboutPreview(page);
}

function collectAboutPagePayload(form) {
  const formData = new FormData();

  formData.append("title", form.title.value.trim());
  formData.append("lead", form.lead.value.trim());
  formData.append("story_title", form.story_title.value.trim());
  formData.append(
    "story_content",
    window.tinymce && tinymce.get("story_content") && tinymce.get("story_content").initialized
      ? tinymce.get("story_content").getContent()
      : form.story_content.value.trim()
  );
  formData.append("mission_title", form.mission_title.value.trim());
  formData.append(
    "mission_content",
    window.tinymce && tinymce.get("mission_content") && tinymce.get("mission_content").initialized
      ? tinymce.get("mission_content").getContent()
      : form.mission_content.value.trim()
  );

  const imageFile = form.image?.files?.[0];
  if (imageFile) {
    formData.append("image", imageFile);
  }

  return formData;
}

function previewPayloadFromForm(form) {
  return {
    title: form?.title?.value?.trim() || "",
    lead: form?.lead?.value?.trim() || "",
    story_title: form?.story_title?.value?.trim() || "",
    story_content:
      window.tinymce && tinymce.get("story_content") && tinymce.get("story_content").initialized
        ? tinymce.get("story_content").getContent()
        : form?.story_content?.value?.trim() || "",
    mission_title: form?.mission_title?.value?.trim() || "",
    mission_content:
      window.tinymce && tinymce.get("mission_content") && tinymce.get("mission_content").initialized
        ? tinymce.get("mission_content").getContent()
        : form?.mission_content?.value?.trim() || "",
  };
}

function bindLivePreview(form) {
  const watchedFields = ["title", "lead", "story_title", "mission_title"];

  watchedFields.forEach((fieldName) => {
    const field = form[fieldName];
    if (!field) return;

    field.addEventListener("input", () => {
      fillAboutPreview(previewPayloadFromForm(form));
    });
  });

  setTimeout(() => {
    const storyEditor = window.tinymce ? tinymce.get("story_content") : null;
    const missionEditor = window.tinymce ? tinymce.get("mission_content") : null;

    if (storyEditor && storyEditor.initialized) {
      storyEditor.on("input change keyup setcontent", () => {
        fillAboutPreview(previewPayloadFromForm(form));
      });
    }

    if (missionEditor && missionEditor.initialized) {
      missionEditor.on("input change keyup setcontent", () => {
        fillAboutPreview(previewPayloadFromForm(form));
      });
    }
  }, 0);
}

function bindImagePreview(form) {
  const input = form.image;
  const preview = document.getElementById("aboutImagePreview");
  const previewEmpty = document.getElementById("aboutImagePreviewEmpty");

  if (!input || !preview || !previewEmpty) return;

  input.addEventListener("change", () => {
    const file = input.files?.[0];

    if (!file) {
      preview.hidden = true;
      previewEmpty.hidden = false;
      preview.removeAttribute("src");
      return;
    }

    preview.src = URL.createObjectURL(file);
    preview.hidden = false;
    previewEmpty.hidden = true;
  });
}

async function initDashboardAboutPage() {
  await initDashboardLayout("");

  const form = document.getElementById("aboutPageForm");
  const statusNode = document.getElementById("aboutPageFormStatus");
  const submitBtn = document.getElementById("aboutPageSubmitBtn");

  if (!form) return;

  bindBlockToggles();
  await initAboutEditors();
  bindImagePreview(form);
  bindLivePreview(form);

  let pageId = null;

  try {
    const pages = await getDashboardAboutPages();

    if (Array.isArray(pages) && pages.length > 0) {
      const page = pages[0];
      pageId = page.id;
      fillAboutPageForm(form, page);
    } else {
      fillAboutImagePreview("");
      fillAboutPreview({});
    }
  } catch (error) {
    console.error(error);
    statusNode.textContent = `Не удалось загрузить данные страницы: ${error.message}`;
    statusNode.className = "dashboard-form-status is-error";
    fillAboutImagePreview("");
    fillAboutPreview({});
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const payload = collectAboutPagePayload(form);

    submitBtn.disabled = true;
    statusNode.textContent = "Сохраняем...";
    statusNode.className = "dashboard-form-status";

    try {
      if (pageId) {
        await updateDashboardAboutPage(pageId, payload);
      } else {
        const createdPage = await createDashboardAboutPage(payload);
        pageId = createdPage.id;
      }

      fillAboutPreview(previewPayloadFromForm(form));

      statusNode.textContent = "Страница успешно сохранена.";
      statusNode.className = "dashboard-form-status is-success";
    } catch (error) {
      console.error(error);
      statusNode.textContent = `Не удалось сохранить страницу: ${error.message}`;
      statusNode.className = "dashboard-form-status is-error";
    } finally {
      submitBtn.disabled = false;
    }
  });
}

initDashboardAboutPage();