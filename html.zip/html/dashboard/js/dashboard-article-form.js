function getArticleIdFromUrl() {
  const params = new URLSearchParams(window.location.search);
  return params.get("id");
}

function transliterateArticle(text) {
  const map = {
    а: "a", б: "b", в: "v", г: "g", д: "d", е: "e", ё: "e", ж: "zh",
    з: "z", и: "i", й: "y", к: "k", л: "l", м: "m", н: "n", о: "o",
    п: "p", р: "r", с: "s", т: "t", у: "u", ф: "f", х: "h", ц: "ts",
    ч: "ch", ш: "sh", щ: "sch", ъ: "", ы: "y", ь: "", э: "e", ю: "yu", я: "ya"
  };

  return text
    .toLowerCase()
    .split("")
    .map((char) => map[char] ?? char)
    .join("");
}

function slugifyArticle(value) {
  return transliterateArticle(value)
    .trim()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9\-_]/g, "")
    .replace(/\-\-+/g, "-");
}

function fillArticleForm(form, article) {
  form.title.value = article.title || "";
  form.slug.value = article.slug || "";
  form.category.value = article.category || "";
  form.excerpt.value = article.excerpt || "";
  form.content.value = article.content || "";
  form.is_published.checked = Boolean(article.is_published);
}

function collectArticleFormData(form) {
  const formData = new FormData();

  formData.append("title", form.title.value.trim());
  formData.append("slug", form.slug.value.trim());
  formData.append("category", form.category.value);
  formData.append("excerpt", form.excerpt.value.trim());
  formData.append("content", form.content.value.trim());
  formData.append("is_published", form.is_published.checked ? "true" : "false");

  const coverFile = form.cover_image?.files?.[0];
  if (coverFile) {
    formData.append("cover_image", coverFile);
  }

  return formData;
}

function renderArticleCoverPreviewFromUrl(url) {
  const previewImage = document.getElementById("articleCoverPreview");
  const previewEmpty = document.getElementById("articleCoverPreviewEmpty");

  if (!previewImage || !previewEmpty) return;

  if (!url) {
    previewImage.hidden = true;
    previewImage.removeAttribute("src");
    previewEmpty.hidden = false;
    return;
  }

  previewImage.src = dashboardImageUrl(url);
  previewImage.hidden = false;
  previewEmpty.hidden = true;
}

function bindArticleCoverPreview(form) {
  const input = document.getElementById("articleCoverImage");
  const previewImage = document.getElementById("articleCoverPreview");
  const previewEmpty = document.getElementById("articleCoverPreviewEmpty");

  if (!input || !previewImage || !previewEmpty) return;

  input.addEventListener("change", () => {
    const file = input.files?.[0];

    if (!file) {
      previewImage.hidden = true;
      previewImage.removeAttribute("src");
      previewEmpty.hidden = false;
      return;
    }

    const objectUrl = URL.createObjectURL(file);
    previewImage.src = objectUrl;
    previewImage.hidden = false;
    previewEmpty.hidden = true;
  });
}

async function initDashboardArticleForm() {
  await initDashboardLayout("");

  const form = document.getElementById("articleForm");
  const heading = document.getElementById("articleFormHeading");
  const lead = document.getElementById("articleFormLead");
  const statusNode = document.getElementById("articleFormStatus");
  const submitBtn = document.getElementById("articleSubmitBtn");

  const articleId = getArticleIdFromUrl();

  if (!form) return;

  bindArticleCoverPreview(form);

  form.title.addEventListener("input", () => {
    if (!form.slug.dataset.userEdited) {
      form.slug.value = slugifyArticle(form.title.value);
    }
  });

  form.slug.addEventListener("input", () => {
    form.slug.dataset.userEdited = "true";
  });

  if (articleId) {
    heading.textContent = "Редактировать статью";
    lead.textContent = "Измените данные статьи и сохраните изменения.";

    try {
      const article = await getDashboardArticleById(articleId);
      fillArticleForm(form, article);
      renderArticleCoverPreviewFromUrl(article.cover_image);
    } catch (error) {
      console.error(error);
      statusNode.textContent = "Ошибка загрузки статьи.";
      statusNode.className = "dashboard-form-status is-error";
    }
  }

  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const payload = collectArticleFormData(form);

    submitBtn.disabled = true;
    statusNode.textContent = articleId
      ? "Сохраняем изменения..."
      : "Создаём статью...";
    statusNode.className = "dashboard-form-status";

    try {
      if (articleId) {
        await updateDashboardArticle(articleId, payload);
        window.location.href = "articles.html";
        return;
      } else {
        await createDashboardArticle(payload);
        window.location.href = form.is_published.checked
          ? "articles.html"
          : "articles.html?published=false";
        return;
      }

      statusNode.className = "dashboard-form-status is-success";
    } catch (error) {
      console.error(error);
      statusNode.textContent = "Не удалось сохранить статью. Проверь обязательные поля, slug и файл изображения.";
      statusNode.className = "dashboard-form-status is-error";
    } finally {
      submitBtn.disabled = false;
    }
  });
}

initDashboardArticleForm();